﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project_App
{
    /// <summary>
    /// Логика взаимодействия для AddEditPage.xaml
    /// </summary>
    public partial class AddEditPage : Page
    {
        private Product _currentProduct = new Product();
        public AddEditPage(Product selectedProduct)
        {
            InitializeComponent();


            if (selectedProduct != null)
                _currentProduct = selectedProduct;




            DataContext = _currentProduct;
            ComboIsActive.ItemsSource = abilov2Entities.GetContext().Product.ToList();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentProduct.Title))
                errors.AppendLine("Укажите название товара");
            if (_currentProduct.IsActive == null)
                errors.AppendLine("Укажите актуальность - True или False");
            if (_currentProduct.Cost == null)
                errors.AppendLine("Укажите цену");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_currentProduct.ID == 0)
                abilov2Entities.GetContext().Product.Add(_currentProduct);

            try
            {
                abilov2Entities.GetContext().SaveChanges();
                MessageBox.Show("Информация сохранена!");
                Manager.MainFrame.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

         
        }
    }
}
