﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project_App
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        public Page1()
        {
            InitializeComponent();
            //DGridOils.ItemsSource = abilov2Entities.GetContext().Product.ToList();
        }

        private void BthEdit_Click(object sender, RoutedEventArgs e)
        {


            Manager.MainFrame.Navigate(new AddEditPage((sender as Button).DataContext as Product));
        }

        private void BthDelete_Click(object sender, RoutedEventArgs e)
        {
            var productsForRemoving = DGridOils.SelectedItems.Cast<Product>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующие {productsForRemoving.Count()} элементы?", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    abilov2Entities.GetContext().Product.RemoveRange(productsForRemoving);
                    abilov2Entities.GetContext().SaveChanges();
                    MessageBox.Show("Данные успешно удалены!");

                    DGridOils.ItemsSource = abilov2Entities.GetContext().Product.ToList();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BthAdd_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AddEditPage(null));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)


        {
            if (Visibility == Visibility.Visible)
            {
                abilov2Entities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridOils.ItemsSource = abilov2Entities.GetContext().Product.ToList();
            }
        }

    }
}
