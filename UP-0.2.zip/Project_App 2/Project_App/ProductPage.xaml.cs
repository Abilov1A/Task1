﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project_App
{
    /// <summary>
    /// Логика взаимодействия для ProductPage.xaml
    /// </summary>
    public partial class ProductPage : Page
    {

        
        
        
        public ProductPage()
        {
            InitializeComponent();
           var allTypes = AbilovEntities1.GetContext().Type.ToList();
            allTypes.Insert(0, new Type
           {
               Name = "Все типы"
            });
            ComboType.ItemsSource = allTypes;

            CheckActive.IsChecked = true;
            ComboType.SelectedIndex = 0;
            UpdateProduct();

          

        }
        
        
        
        private void UpdateProduct()
        {
            var currentProduct = AbilovEntities1.GetContext().Product.ToList();

            if (ComboType.SelectedIndex > 0)
                currentProduct = currentProduct.Where(p => p.Type.Contains(ComboType.SelectedItem as Type)).ToList();

            currentProduct = currentProduct.Where(p => p.Title.ToLower().Contains(TBoxSearch.Text.ToLower())).ToList();

            if (CheckActive.IsChecked.Value)
                currentProduct = currentProduct.Where(p => p.IsActive).ToList();

            LViewProduct.ItemsSource = currentProduct;

        }

        private void TBoxSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateProduct();


        }

        private void ComboType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            UpdateProduct();
        }

        private void CheckActive_Checked(object sender, RoutedEventArgs e)
        {
            UpdateProduct();
        }

    }
}
